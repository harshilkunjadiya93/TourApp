package com.example.tourapp;

public interface selectListener {
    void onItemClicked(itemState itemState);
    void onItemClicked(itemPlace itemPlace);
}
