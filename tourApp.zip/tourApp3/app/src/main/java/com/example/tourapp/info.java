package com.example.tourapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class info extends AppCompatActivity {

    ImageView img;
    TextView txt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);
        img = findViewById(R.id.img);
        txt = findViewById(R.id.txt);
        Intent i = getIntent();
        String placeName = i.getStringExtra("placeName");
        String stateName = i.getStringExtra("stateName");
        String placeID = i.getStringExtra("placeID");
        String tempplace = placeName;
        String[] place = getResources().getStringArray(R.array.Gujarat);
        placeName = place[Integer.parseInt(placeID)];

        String imgname = stateName.toLowerCase()+"_"+placeName.toLowerCase();
        img.setImageResource(getResources().getIdentifier(imgname,"drawable",getPackageName()));

        txt.setText(stateName.toLowerCase()+"_"+placeName.toLowerCase());
//        int imagename = getResources().getIdentifier(imgname,"drawable",getPackageName());
//        img.setImageResource(imagename);
    }
}