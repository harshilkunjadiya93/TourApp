package com.example.tourapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

public class place extends AppCompatActivity implements selectListener {
    String stateName;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_place);

        RecyclerView recyclerView = findViewById(R.id.recyclerview);

        List<itemPlace> items = new ArrayList<itemPlace>();

        Intent intent = getIntent();
        stateName = intent.getStringExtra("stateName");

        Toast.makeText(this, stateName, Toast.LENGTH_SHORT).show();

        String[] place = getResources().getStringArray(getplace(stateName));
            int[] img = new int[place.length];

        for (int i = 0; i < place.length; i++) {
            String tempimg = place[i].toLowerCase(Locale.ROOT);
            System.out.println(tempimg);
            String imgname = stateName.toLowerCase()+"_"+tempimg;
            img[i] = getResources().getIdentifier(imgname,"drawable",getPackageName());
        }

        for (int i = 0; i < place.length ; i++) {
            items.add(new itemPlace(String.valueOf(i),place[i].replace("_"," "), img[i]));
        }

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new adapterPlace(getApplicationContext(),items,this));
    }

    int getplace(String stateName){
        int img = getResources().getIdentifier(stateName,"array",getPackageName());
        return img;
    }

    @Override
    public void onItemClicked(itemState itemState) {

    }

    @Override
    public void onItemClicked(itemPlace itemPlace) {
        startActivity(new Intent(getApplicationContext(),info.class).putExtra("placeName",itemPlace.getName()).putExtra("stateName",stateName).putExtra("placeID",itemPlace.getPlaceID()));
        Toast.makeText(this, itemPlace.getName(), Toast.LENGTH_SHORT).show();
    }
}